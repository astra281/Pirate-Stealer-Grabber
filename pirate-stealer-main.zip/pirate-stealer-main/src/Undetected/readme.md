### Undectected version

Same features as C# version (thanks stanley)

Please refrain from uploading it to virustotal thanks
